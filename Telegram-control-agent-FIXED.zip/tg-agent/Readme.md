# 🖥 Telegram Control Agent

Telegram бот для мониторинга Linux сервера. Показывает статус ресурсов в канале и автообновляет его каждые 5 минут без спама.

## ⚡ Установка одной командой

```bash
git clone https://github.com/tarpy-socdev/Telegram-control-agent.git /opt/tg-control-agent
cd /opt/tg-control-agent
sudo ./install.sh install
sudo ./install.sh configure
sudo ./install.sh start
```

## 🎮 Команды бота

| Команда | Описание |
|---|---|
| `/status` | Текущий статус CPU, RAM, Disk, Network |
| `/services` | Список работающих systemd служб |
| `/ports` | Открытые порты с процессами |
| `/ping <хост>` | Пинг хоста |
| `/restart_service <имя>` | Перезапустить службу (с подтверждением) |
| `/logs <служба> [строк]` | Просмотр журнала службы |
| `/reboot` | Перезагрузить сервер (с подтверждением) |
| `/clear_logs` | Очистить journalctl |
| `/close_port <порт>` | Завершить процесс на порту |
| `/test_update` | Обновить статус в каналах прямо сейчас |

## 🔧 Управление

```bash
sudo ./install.sh start        # запустить
sudo ./install.sh stop         # остановить
sudo ./install.sh restart      # перезапустить
sudo ./install.sh status       # статус systemd сервиса
sudo ./install.sh logs 200     # последние 200 строк логов
sudo ./install.sh logs-live    # логи в реальном времени
sudo ./install.sh diagnose     # диагностика проблем
sudo ./install.sh update       # обновить с GitHub
sudo ./install.sh configure    # изменить токен / ID
```

## 🔑 Конфигурация

Все настройки в файле `.env` (создаётся при установке):

```env
BOT_TOKEN=ваш_токен_от_BotFather
ADMIN_IDS=123456789,987654321
UPDATE_INTERVAL=300
```

> ⚠️ `.env` добавлен в `.gitignore` — токен **никогда** не попадает в репозиторий.

## 📋 Структура проекта

```
├── bot/
│   ├── main.py              # точка входа
│   ├── config.py            # загрузка .env
│   ├── core/
│   │   └── controller.py    # управление systemd, портами
│   ├── monitor/
│   │   └── server.py        # CPU, RAM, Disk, службы, порты, ping
│   ├── storage/
│   │   └── status_store.py  # хранение ID сообщений каналов
│   └── telegram/
│       ├── handlers.py      # все команды и callbacks
│       ├── keyboards.py     # inline клавиатуры
│       └── formatter.py     # форматирование сообщений
├── .env.example             # шаблон конфига
├── requirements.txt
└── install.sh               # установка и управление
```

## 🛡️ Безопасность

- Команды управления доступны только пользователям из `ADMIN_IDS`
- Критичные операции (restart, reboot, close port) требуют подтверждения
- Токен хранится в `.env`, не в коде
